"""
Agent orchestration for Option C.

Defines a simple pipeline that runs three calls to the OpenAI API
using system prompts loaded from the prompts folder. The first call
generates a research brief (Imbokodo), the second produces a pre‑IC
screen (Baobab) and the third drafts an IC memo (Athena). This logic
serves as a lightweight alternative to CrewAI for environments where
you prefer direct API calls.
"""

import os
from openai import OpenAI
from app.rag import rag_query

client = OpenAI()

# Load system prompts for each role
def _load_prompt(name: str) -> str:
    path = os.path.join(os.path.dirname(__file__), 'prompts', f'{name}.md')
    with open(path, encoding='utf-8') as f:
        return f.read()

ATHENA = _load_prompt('athena')
BAOBAB = _load_prompt('baobab')
IMBOKODO = _load_prompt('imbokodo')

MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1")


def call_llm(system_prompt: str, user_prompt: str) -> str:
    """Call the chat completion API with a system and user prompt.

    Args:
        system_prompt: The system context for the model.
        user_prompt: The user message containing instructions and context.

    Returns:
        The assistant message content from the first choice.
    """
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.2,
    )
    return resp.choices[0].message.content


def run_pipeline(deal: dict) -> dict:
    """Execute the research and memo drafting pipeline.

    Args:
        deal: Dictionary with at least a `topic` field.

    Returns:
        Dictionary containing the outputs of the three agent stages.
    """
    topic = deal.get("topic", "Sub‑Saharan Africa edtech expansion")
    # 1) Imbokodo research (with RAG)
    context = rag_query(topic)
    analyst_out = call_llm(IMBOKODO, f"Use this context to write a research brief:\n\n{context}")
    # 2) Baobab pre‑IC screen
    associate_out = call_llm(BAOBAB, f"Turn this into a pre‑IC screen with DD checklist:\n\n{analyst_out}")
    # 3) Athena IC memo
    principal_out = call_llm(ATHENA, f"Draft an IC memo with scenarios & recommendation from:\n\n{associate_out}")
    return {
        "analyst": analyst_out,
        "associate": associate_out,
        "principal": principal_out,
    }