"""FastAPI application for OACP digital employees stack.

This package contains the API routes, agent orchestration logic,
retrieval‑augmented generation (RAG) helpers, security utilities and
prompt files used by the enterprise deployment of the OACP AI
employees. The structure mirrors the Option C description in the
implementation guide.
"""