"""
Security helpers for the OACP FastAPI service.

Provides a simple bearer token verification function. In production
this should be replaced with a proper authentication and
authorisation layer (e.g. OAuth2, JWT tokens, RBAC).
"""

import os


def verify_token(auth_header: str) -> bool:
    """Verify that the provided Authorization header contains the configured token.

    Args:
        auth_header: The raw Authorization header value, expected to be
            of the form "Bearer <token>".

    Returns:
        True if the token matches the `AUTH_TOKEN` environment variable,
        False otherwise.
    """
    token = os.getenv("AUTH_TOKEN", "change_me")
    return auth_header == f"Bearer {token}"