"""
FastAPI entrypoint for the OACP digital employee stack.

This module defines two HTTP endpoints:

  * `/health`: simple health check that returns status OK.
  * `/pipeline`: triggers the Imbokodo->Baobab->Athena pipeline to
    analyse an investment theme. Requires a valid Authorization header.
  * `/ask`: performs a retrieval augmented query. Also protected by
    authorization.

Requests must include an `Authorization` header containing the
string `Bearer <AUTH_TOKEN>` where `<AUTH_TOKEN>` is configured in
your `.env` or Docker environment. See `security.py` for the
verification logic.
"""

from fastapi import FastAPI, Header, HTTPException
from app.agents import run_pipeline
from app.rag import rag_query
from app.security import verify_token

app = FastAPI(title="OACP Digital Employees")


@app.get("/health")
def health():
    """Health check endpoint returning a simple status dict."""
    return {"status": "ok"}


@app.post("/pipeline")
async def pipeline(deal: dict, authorization: str = Header(None)):
    """Run the full investment pipeline.

    Expects a JSON payload containing at least a `topic` field. Uses
    Imbokodo to research, Baobab to screen and Athena to draft a memo.
    Requires Bearer token authentication. Returns a dict with the
    outputs of each agent.
    """
    if not verify_token(authorization):
        raise HTTPException(status_code=401, detail="unauthorized")
    # Orchestrate Imbokodo -> Baobab -> Athena
    return run_pipeline(deal)


@app.post("/ask")
async def ask(query: dict, authorization: str = Header(None)):
    """Answer arbitrary questions using the RAG layer.

    Accepts JSON with a single field `q`. Looks up relevant context
    using the vector database and returns an answer. Requires Bearer
    token.
    """
    if not verify_token(authorization):
        raise HTTPException(status_code=401, detail="unauthorized")
    return {"answer": rag_query(query.get("q", ""))}