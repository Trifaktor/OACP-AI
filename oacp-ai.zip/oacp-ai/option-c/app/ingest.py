"""
Document ingestion script for Option C.

This script walks a directory tree and would normally extract text
from PDF/Word documents, embed the text using a language model and
store the embeddings in a Qdrant collection. In this scaffold the
logic is stubbed out for demonstration purposes; it simply prints
the file paths. Replace the TODOs with your preferred ingestion
pipeline (e.g. using LangChain loaders and OpenAI embeddings).
"""

import os
import glob
from uuid import uuid4
import requests

QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
COLLECTION = "oacp_docs"

# TODO: implement text extraction + embeddings, then upsert to Qdrant
# Pseudocode placeholder to show the flow only


def ingest_folder(path: str) -> None:
    """Recursively ingest all documents under `path`.

    For each file encountered, extract its text and embedding and
    upsert the vector into Qdrant. Currently this just prints the
    filenames as a stub.
    """
    files = glob.glob(os.path.join(path, "**/*.*"), recursive=True)
    for f in files:
        print("Stub ingest:", f)
        # 1) extract_text = ...
        # 2) embedding = ...
        # 3) upsert into Qdrant via REST


if __name__ == "__main__":
    ingest_folder("/data/docs")